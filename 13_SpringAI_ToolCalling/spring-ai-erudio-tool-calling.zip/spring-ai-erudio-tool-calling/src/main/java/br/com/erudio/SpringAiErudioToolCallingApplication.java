package br.com.erudio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAiErudioToolCallingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAiErudioToolCallingApplication.class, args);
	}

}
